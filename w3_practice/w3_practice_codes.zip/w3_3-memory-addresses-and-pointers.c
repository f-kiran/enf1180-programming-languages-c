/* Observe how a pointer stores an address and accesses a variable's value. */
/* This program demonstrates the use of pointers in C. It prompts the user 
to enter a whole-number score, stores it in a variable, 
and then uses a pointer to access and modify that variable's value. 
The program also displays the size of the variable and the pointer. */

/* gcc w3_3-memory-addresses-and-pointers.c -o w3_3-memory-addresses-and-pointers */
#include <stdio.h>

int main(void) {
    int score;
    /* &score gets the variable's address, which is stored in this pointer. */
    int *score_pointer = &score;

    printf("Enter a whole-number score: ");
    if (scanf("%d", &score) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }

    printf("\nThe variable and its address:\n");
    printf("score's value: %d\n", score);
    printf("score's address (using &): %p\n", (void *)&score);

    printf("\nThe pointer:\n");
    printf("score_pointer stores this address: %p\n", (void *)score_pointer);
    /* Dereferencing with * accesses the value at the stored address. */
    printf("Value at that address (using *): %d\n", *score_pointer);

    *score_pointer = score + 1;
    printf("\nAfter adding 1 through the pointer:\n");
    printf("score's new value: %d\n", score);

    printf("\nSize of score: %zu byte(s)\n", sizeof score);
    printf("Size of score_pointer: %zu byte(s)\n", sizeof score_pointer);
    printf("A pointer stores an address; its size can vary by system.\n");

    return 0;
}
