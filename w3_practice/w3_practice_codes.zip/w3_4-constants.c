/* Compare a const variable with a #define constant in calculations. */
/* This program demonstrates the use of constants in C. 
It defines a constant for the number of centimeters per inch and a const variable for the value of pi, 
then uses these in calculations. */

/* gcc w3_4-constants.c -o w3_4-constants */

#include <stdio.h>

#define CM_PER_INCH 2.54

int main(void) {
    const double PI = 3.14159;
    double radius;
    double inches;

    printf("Enter the radius of a circle: ");
    if (scanf("%lf", &radius) != 1 || radius < 0) {
        printf("Please enter a non-negative number.\n");
        return 1;
    }

    printf("Enter a length in inches: ");
    if (scanf("%lf", &inches) != 1 || inches < 0) {
        printf("Please enter a non-negative number.\n");
        return 1;
    }

    printf("\nCircle calculations using const double PI = %.5f:\n", PI);
    printf("Circumference: %.2f\n", 2 * PI * radius);
    printf("Area: %.2f\n", PI * radius * radius);

    printf("\nLength conversion using #define CM_PER_INCH %.2f:\n",
           (double)CM_PER_INCH);
    printf("%.2f inches = %.2f centimetres\n",
           inches, inches * CM_PER_INCH);

    printf("\nPI is a typed const variable (size: %zu byte(s)).\n",
           sizeof PI);
    printf("CM_PER_INCH is a preprocessor constant, replaced before compilation.\n");
    printf("Use named constants to make calculations easier to read and update.\n");

    return 0;
}
