/* Observe implicit and explicit conversions and compare integer and double division. */
/* This program demonstrates type conversions in C. 
It shows how values are implicitly converted between types, 
how to explicitly convert types using casts, 
and the difference between integer and floating-point division. */

/* gcc w3_5-type-conversions.c -o w3_5-type-conversions */
#include <stdio.h>

int main(void) {
    int numerator;
    int denominator;
    double measurement;
    double converted_value;
    int whole_number;

    printf("Enter a whole-number numerator: ");
    if (scanf("%d", &numerator) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }

    printf("Enter a whole-number denominator: ");
    if (scanf("%d", &denominator) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }

    printf("Enter a decimal measurement: ");
    if (scanf("%lf", &measurement) != 1) {
        printf("Please enter a number.\n");
        return 1;
    }

    printf("\nImplicit conversion (int to double):\n");
    converted_value = numerator;
    printf("The int %d is stored in a double as %.2f.\n",
           numerator, converted_value);

    printf("\nExplicit conversion (double to int):\n");
    /* Converting a floating-point value to int discards its fractional part. */
    whole_number = (int)measurement;
    printf("%.3f converted to int is %d; the fractional part is discarded.\n",
           measurement, whole_number);

    printf("\nDivision:\n");
    if (denominator == 0) {
        printf("Cannot divide by zero; division examples are skipped.\n");
    } else {
        printf("%d / %d using int division = %d\n",
               numerator, denominator, numerator / denominator);
        /* Cast before division so C performs floating-point rather than integer division. */
        printf("(double)%d / %d using double division = %.3f\n",
               numerator, denominator,
               (double)numerator / denominator);
    }

    printf("\nAssigning an int to a double can happen implicitly.\n");
    printf("Use a cast when you want to make a conversion explicit.\n");

    return 0;
}
