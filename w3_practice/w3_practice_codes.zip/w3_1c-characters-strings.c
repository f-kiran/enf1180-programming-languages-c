/* Compare reading characters, single-word strings, and full lines. */
/* This program demonstrates the use of character and string input in C.
It prompts the user to enter a first initial, a letter grade, a first name (single word), and a full name (which may include spaces). 
The program then displays the entered values along with their sizes in bytes and lengths, and explains the differences in input methods. */

/* gcc w3_1c-characters-strings.c -o w3_1c-characters-strings */

#include <stdio.h>
#include <string.h>

int main(void) {
    char initial;
    char grade;
    char first_name[50];
    char full_name[80];

    printf("Enter your first initial: ");
    /* The leading space skips whitespace left in the input, including a newline. */
    if (scanf(" %c", &initial) != 1) {
        printf("Please enter a character.\n");
        return 1;
    }

    printf("Enter a letter grade: ");
    if (scanf(" %c", &grade) != 1) {
        printf("Please enter a character.\n");
        return 1;
    }

    printf("Enter your first name (one word): ");
    /* The width leaves one byte for the string's terminating '\0'. */
    if (scanf("%49s", first_name) != 1) {
        printf("Please enter a name.\n");
        return 1;
    }

    int character;
    /* Discard the rest of the line so fgets reads the next response. */
    while ((character = getchar()) != '\n' && character != EOF) {
    }

    printf("Enter your full name (spaces are allowed): ");
    /* fgets reads spaces and may include the newline in the buffer. */
    if (fgets(full_name, sizeof full_name, stdin) == NULL) {
        printf("Could not read your full name.\n");
        return 1;
    }

    /* Replace the newline captured by fgets with the string terminator. */
    full_name[strcspn(full_name, "\n")] = '\0';

    printf("\nHello, %s %c!\n", first_name, initial);
    printf("Initial: %c (size: %zu byte(s))\n", initial, sizeof initial);
    printf("Grade: %c (size: %zu byte(s))\n", grade, sizeof grade);
    printf("First name: %s (array size: %zu byte(s))\n",
           first_name, sizeof first_name);
    printf("Full name: %s (length: %zu characters, array size: %zu byte(s))\n",
           full_name, strlen(full_name), sizeof full_name);
    printf("A single character uses %%c; %%s reads one word; fgets reads a line.\n");
    printf("String array sizes include space for the ending '\\0'.\n");

    return 0;
}
