/* Compare float and double sizes, precision, and notation. */

/* This program demonstrates the use of different floating-point types in C.
It prompts the user to enter values for float and double types, 
then displays the entered values along with their sizes in bytes.

The program also highlights the appropriate format specifiers for each floating-point type and discusses the differences in precision and notation. 
*/

/* gcc w3_1b-floating-point.c -o w3_1b-floating-point */
#include <stdio.h>

int main(void) {
    float height;
    double distance;
    double small_number;

    printf("Enter your height in metres (float): ");
    /* scanf uses %f for float; a double input requires %lf. */
    if (scanf("%f", &height) != 1) {
        printf("Please enter a number.\n");
        return 1;
    }
    // double means "double precision" floating point number, which is more precise than float.
    printf("Enter a distance in kilometres (double): ");
    if (scanf("%lf", &distance) != 1) {
        printf("Please enter a number.\n");
        return 1;
    }

    printf("Enter a small number (for example, 0.000025): ");
    if (scanf("%lf", &small_number) != 1) {
        printf("Please enter a number.\n");
        return 1;
    }

    printf("\nYour height: %.2f metres (size: %zu byte(s))\n",
           height, sizeof height);
    printf("Height with more decimal places: %.8f metres\n", height);
    printf("Distance: %.6f kilometres (size: %zu byte(s))\n",
           distance, sizeof distance);
    printf("Small number in decimal notation: %.8f\n", small_number);
    printf("Small number in scientific notation: %e (size: %zu byte(s))\n",
           small_number, sizeof small_number);
    printf("For scanf, float uses %%f and double uses %%lf.\n");
    printf("For printf, both types use %%f; %%e displays scientific notation.\n");

    return 0;
}
