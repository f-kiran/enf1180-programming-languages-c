/* Try two integers and observe arithmetic, equality, and comparison results. */
/* This program demonstrates the use of arithmetic, equality, and comparison operators in C.
It prompts the user to enter two whole numbers, performs various arithmetic operations, and compares the two numbers using equality and relational operators. 
The results of these operations are displayed to the user, along with explanations of the output. */

/* gcc w3_2-arithmetic-and-comparison-operators.c -o w3_2-arithmetic-and-comparison-operators */

#include <stdio.h>

const char *describe_result(int result) {
    /* Comparisons produce 1 or 0; convert that value to readable text. */
    return result ? "true (1)" : "false (0)";
}

int main(void) {
    int first;
    int second;

    printf("Enter a whole number: ");
    if (scanf("%d", &first) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }

    printf("Enter another whole number: ");
    if (scanf("%d", &second) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }

    printf("\nArithmetic operators for %d and %d:\n", first, second);
    /* Convert before each operation so it is evaluated as long long arithmetic. */
    printf("%d + %d = %lld\n", first, second,
           (long long)first + second);
    printf("%d - %d = %lld\n", first, second,
           (long long)first - second);
    printf("%d * %d = %lld\n", first, second,
           (long long)first * second);

    if (second != 0) {
        /* Integer division truncates, and both division and remainder require a nonzero divisor. */
        printf("%d / %d = %lld (integer division)\n", first, second,
               (long long)first / second);
        printf("%d %% %d = %lld (remainder)\n", first, second,
               (long long)first % second);
    } else {
        printf("Division and remainder are skipped because the second number is 0.\n");
    }

    printf("\nEquality operators:\n");
    printf("%d == %d: %s\n", first, second,
           describe_result(first == second));
    printf("%d != %d: %s\n", first, second,
           describe_result(first != second));

    printf("\nRelational operators:\n");
    printf("%d <  %d: %s\n", first, second,
           describe_result(first < second));
    printf("%d <= %d: %s\n", first, second,
           describe_result(first <= second));
    printf("%d >  %d: %s\n", first, second,
           describe_result(first > second));
    printf("%d >= %d: %s\n", first, second,
           describe_result(first >= second));

    return 0;
}
