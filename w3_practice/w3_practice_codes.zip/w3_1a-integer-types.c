/*
 * Enter values for each integer type, then compare their
 * input format specifiers and sizes. Which types can represent larger values?
 */

/* This program demonstrates the use of different integer types in C.
It prompts the user to enter values for short, int, unsigned int, long, and long long types, 
then displays the entered values along with their sizes in bytes.

The program also highlights the appropriate format specifiers for each integer type and discusses which types can represent larger values. */

/* gcc w3_1a-integer-types.c -o w3_1a-integer-types */

#include <stdio.h>

int main(void) {
    short year;
    int age;
    unsigned int students;
    long population;
    long long seconds;

    // short number example is 25
    printf("Enter the current year (short): ");
    // Use %hd for short integers
    if (scanf("%hd", &year) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }
    // int means whole number, example is 25
    printf("Enter your age (int): ");
    // Use %d for int integers
    if (scanf("%d", &age) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }
    // unsigned int means non-negative integers, example is 123456
    printf("Enter the number of students (unsigned int): ");
    // Use %u for unsigned int integers
    if (scanf("%u", &students) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }
    // long  number example is 1234567890
    printf("Enter a population value (long): ");
    // Use %ld for long integers
    if (scanf("%ld", &population) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }
    // long long large number example is 1234567890123456789
    printf("Enter a large number of seconds (long long): ");
    // Use %lld for long long integers 
    if (scanf("%lld", &seconds) != 1) {
        printf("Please enter a whole number.\n");
        return 1;
    }

    printf("\nYou entered:\n");
    printf("Year: %hd (size: %zu byte(s))\n", year, sizeof year);
    printf("Age: %d (size: %zu byte(s))\n", age, sizeof age);
    printf("Students: %u (size: %zu byte(s))\n", students, sizeof students);
    printf("Population: %ld (size: %zu byte(s))\n", population, sizeof population);
    printf("Seconds: %lld (size: %zu byte(s))\n", seconds, sizeof seconds);
    printf("Integer input specifiers: %%hd, %%d, %%u, %%ld, and %%lld.\n");

    return 0;
}
